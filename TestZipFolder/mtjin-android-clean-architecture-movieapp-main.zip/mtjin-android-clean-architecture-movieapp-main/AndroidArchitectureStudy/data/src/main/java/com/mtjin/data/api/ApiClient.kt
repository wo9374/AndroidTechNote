package com.mtjin.data.api

object ApiClient {
    const val BASE_URL = "https://openapi.naver.com/"
}