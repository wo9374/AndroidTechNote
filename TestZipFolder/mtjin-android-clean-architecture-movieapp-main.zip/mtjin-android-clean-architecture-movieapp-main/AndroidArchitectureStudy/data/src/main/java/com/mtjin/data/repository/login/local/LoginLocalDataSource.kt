package com.mtjin.data.repository.login.local

interface LoginLocalDataSource {
    var autoLogin: Boolean
}