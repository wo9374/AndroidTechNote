package com.mtjin.data.utils

const val LAST_PAGE= "LAST_PAGE"
const val NO_DATA_FROM_LOCAL_DB= "NO_DATA_FROM_LOCAL_DB"