package com.mtjin.domain.repository

interface LoginRepository {

    var autoLogin: Boolean
}