# AACSamplesPagingNetwork

AAC Paging 샘플 : not using room
차차님의 https://github.com/codechacha/paging-network
차차님의 블로그 설명: https://codechacha.com/ko/android-jetpack-paging/